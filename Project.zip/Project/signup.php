<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "beauty_parlor";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $cust_id = mysqli_real_escape_string($conn, $_POST['cust_id']);
    $cust_name = mysqli_real_escape_string($conn, $_POST['cust_name']);
    $cust_phone = mysqli_real_escape_string($conn, $_POST['cust_phone']);
    $cust_mail = mysqli_real_escape_string($conn, $_POST['cust_mail']);
    $cust_loc = mysqli_real_escape_string($conn, $_POST['cust_loc']);

    // Insert data into database
    $sql = "INSERT INTO customer (cust_id, cust_name, cust_phone, cust_mail, cust_loc) VALUES ('$cust_id', '$cust_name', '$cust_phone', '$cust_mail', '$cust_loc')";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Signup successful! Welcome, $cust_name.</p>";
        // Redirect to login page after successful signup
        header("Location: login.php");
        exit(); // Ensure no further code is executed
    } else {
        echo "<p>Error: " . $sql . "<br>" . $conn->error . "</p>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Signup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .signup-form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        .signup-form h2 {
            margin-bottom: 20px;
            font-size: 24px;
            text-align: center;
        }
        .signup-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        .signup-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .signup-form button {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        .signup-form button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <form class="signup-form" method="POST" action="">
        <h2>Customer Signup</h2>
        <label for="cust_id">Customer ID</label>
        <input type="text" id="cust_id" name="cust_id" required>

        <label for="cust_name">Full Name</label>
        <input type="text" id="cust_name" name="cust_name" required>

        <label for="cust_phone">Phone Number</label>
        <input type="text" id="cust_phone" name="cust_phone" required>

        <label for="cust_mail">Email</label>
        <input type="email" id="cust_mail" name="cust_mail" required>

        <label for="cust_loc">Location</label>
        <input type="text" id="cust_loc" name="cust_loc" required>

        <button type="submit">Sign Up</button>
    </form>
</body>
</html>
