<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "beauty_parlor";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the customer is logged in


$cust_id = $_SESSION['cust_id']; // Retrieve logged-in customer ID

// Fetch customer details
$customer = $conn->query("SELECT cust_name, cust_mail FROM customer WHERE cust_id = '$cust_id'")->fetch_assoc();

// Fetch staff and services
$staff = $conn->query("SELECT staff_id, staff_name FROM staff");
$services = $conn->query("SELECT sid, sname FROM services");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $staff_id = mysqli_real_escape_string($conn, $_POST['staff_id']);
    $service_id = mysqli_real_escape_string($conn, $_POST['service_id']);
    $appointment_date = mysqli_real_escape_string($conn, $_POST['appointment_date']);

    // Insert into the appointment table
    $app_id = "A" . str_pad(rand(1, 999), 3, "0", STR_PAD_LEFT); // Generate unique appointment ID
    $insert_appointment = "INSERT INTO appointment (app_id, app_date, cust_id, staff_id)
                           VALUES ('$app_id', '$appointment_date', '$cust_id', '$staff_id')";

    if ($conn->query($insert_appointment) === TRUE) {
        // Insert into the appointment_details table
        $pay_id = "P" . str_pad(rand(1, 999), 3, "0", STR_PAD_LEFT); // Generate unique payment ID
        $pay_date = date('Y-m-d');
        $insert_details = "INSERT INTO appointment_details (pay_id, app_id, stype_id, pay_date, pay_method, total_bill, status)
                           VALUES ('$pay_id', '$app_id', (SELECT stype_id FROM services WHERE sid = '$service_id'), 
                                   '$pay_date', 'Pending', 
                                   (SELECT sprice FROM services WHERE sid = '$service_id'), 'Pending')";

        if ($conn->query($insert_details) === TRUE) {
            echo "<p>Appointment booked successfully!</p>";
        } else {
            echo "<p>Error saving appointment details: " . $conn->error . "</p>";
        }
    } else {
        echo "<p>Error booking appointment: " . $conn->error . "</p>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book an Appointment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            max-width: 400px;
            margin: auto;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        form h2 {
            margin-bottom: 20px;
        }
        form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        form select, form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        form button {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        form button:hover {
            background-color: #0056b3;
        }

        .logout {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 10px 15px;
            background-color: #f44336; /* Red color */
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        .logout:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <form method="POST" action="">
        <h2>Book an Appointment</h2>

        <p><strong>Welcome, <?= $customer['cust_name'] ?></strong></p>
        <p>Email: <?= $customer['cust_mail'] ?></p>

        <label for="staff_id">Preferred Staff</label>
        <select id="staff_id" name="staff_id" required>
            <option value="">Select Staff</option>
            <?php while ($row = $staff->fetch_assoc()): ?>
                <option value="<?= $row['staff_id'] ?>"><?= $row['staff_name'] ?></option>
            <?php endwhile; ?>
        </select>

        <label for="service_id">Service</label>
        <select id="service_id" name="service_id" required>
            <option value="">Select Service</option>
            <?php while ($row = $services->fetch_assoc()): ?>
                <option value="<?= $row['sid'] ?>"><?= $row['sname'] ?></option>
            <?php endwhile; ?>
        </select>

        <label for="appointment_date">Appointment Date</label>
        <input type="date" id="appointment_date" name="appointment_date" required>

        <button type="submit">Book Appointment</button>
    </form>
    <!-- Logout Button -->
    <a href="logout.php" class="logout">Logout</a>

</body>
</html>
