<?php
session_start();
include 'db_connect.php';

// Initialize search term
$search = '';
if (isset($_POST['search'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']); // Sanitize input
}

// Query to get services based on the search term
$query = "SELECT * FROM services WHERE sid LIKE '%$search%' OR sname LIKE '%$search%' OR sprice LIKE '%$search%' OR sduration LIKE '%$search%'";

$result = $conn->query($query);

// Add new service
if (isset($_POST['add_service'])) {
    $sname = mysqli_real_escape_string($conn, $_POST['sname']);
    $sprice = mysqli_real_escape_string($conn, $_POST['sprice']);
    $sduration = mysqli_real_escape_string($conn, $_POST['sduration']);

    $add_query = "INSERT INTO services (sname, sprice, sduration) VALUES ('$sname', '$sprice', '$sduration')";

    if ($conn->query($add_query) === TRUE) {
        echo "<script>alert('Service added successfully');</script>";
    } else {
        echo "<script>alert('Error adding service: " . $conn->error . "');</script>";
    }

    // Redirect to avoid resubmission of the form
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// Delete service
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id']; // Get the ID to delete
    $delete_query = "DELETE FROM services WHERE sid = '$delete_id'";

    if ($conn->query($delete_query) === TRUE) {
        echo "<script>alert('Service deleted successfully');</script>";
    } else {
        echo "<script>alert('Error deleting service: " . $conn->error . "');</script>";
    }

    // Redirect to avoid resubmission of the form
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beauty Salon</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .options {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }
        .option {
            width: 200px;
            padding: 20px;
            text-align: center;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s;
        }
        .option:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse; /* Collapses borders between table cells */
            margin: 20px 0; /* Adds spacing above and below the table */
            font-family: Arial, sans-serif; /* Sets font family */
        }

        th {
            background-color: #007BFF;
            color: white;
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        caption {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .search-form {
    display: flex;
    justify-content: center; /* Centers the form horizontally */
    align-items: center; /* Ensures proper vertical alignment */
    gap: 10px; /* Adds spacing between the input and button */
    margin-bottom: 20px; /* Space below the form */
}

.search-input {
    padding: 10px; /* Adjusts padding for a better look */
    font-size: 16px; /* Increases font size for readability */
    border: 1px solid #ccc; /* Light gray border */
    border-radius: 4px; /* Rounded corners */
    width: 250px; /* Input width */
    transition: border-color 0.3s, box-shadow 0.3s; /* Smooth transition on focus */
}

.search-input:focus {
    border-color: #007BFF; /* Blue border on focus */
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Glowing effect */
    outline: none; /* Removes default focus outline */
}

.search-btn {
    padding: 10px 15px; /* Increases padding for the button */
    background-color: #007BFF; /* Primary blue color */
    color: white; /* White text color */
    border: none; /* Removes default border */
    border-radius: 4px; /* Rounded corners */
    font-size: 16px; /* Matches font size with input */
    cursor: pointer; /* Adds pointer cursor */
    transition: background-color 0.3s; /* Smooth hover effect */
}

.search-btn:hover {
    background-color: #0056b3; /* Darker blue on hover */
}

        .delete-btn {
            background-color: #f44336; /* Red */
            color: white;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 12px;
        }

        .delete-btn:hover {
            background-color: #e53935;
        }

        .logout {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 10px 15px;
            background-color: #f44336; /* Red color */
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        .logout:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <h1>Welcome to Our Beauty Salon</h1>

    <!-- Search Form -->
    <form method="POST" action="" class="search-form">
        <input type="text" name="search" placeholder="Search Services..." value="<?php echo $search; ?>">
        <button type="submit">Search</button>
    </form>

    <!-- Add Service Form -->
    <div class="container">
        <h2>Add New Service</h2>
        <form method="POST" action="">
            <label for="sname">Service Name:</label>
            <input type="text" id="sname" name="sname" required><br><br>
            
            <label for="sprice">Service Price:</label>
            <input type="number" id="sprice" name="sprice" step="0.01" required><br><br>
            
            <label for="sduration">Service Duration (in minutes):</label>
            <input type="number" id="sduration" name="sduration" required><br><br>
            
            <button type="submit" name="add_service">Add Service</button>
        </form>
    </div>

    <!-- Services List -->
    <div class="container">
        <h2>Services List</h2>
        <table border="1" align="center">
            <tr>
                <th class="option">Service ID</th>
                <th class="option">Service Name</th>
                <th class="option">Price</th>
                <th class="option">Duration</th>
                <th class="option">Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['sid']; ?></td>
                    <td><?php echo $row['sname']; ?></td>
                    <td><?php echo number_format($row['sprice'], 2); ?></td>
                    <td><?php echo $row['sduration']; ?></td>
                    <td>
                        <a href="?delete_id=<?php echo $row['sid']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this service?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <?php
    // Close connection
    $conn->close();
    ?>
</body>
</html>
