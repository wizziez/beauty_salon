<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "beauty_parlor";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// For searching data
$search = '';
if (isset($_POST['search'])) {
    $search = mysqli_real_escape_string($conn, $_POST['search']); // Sanitize input
}

// Query to get appointment_details based on the search term
$query = "SELECT * FROM appointment_details WHERE pay_id LIKE '%$search%' OR pay_date LIKE '%$search%' OR pay_method LIKE '%$search%' OR total_bill LIKE '%$search%' OR status LIKE '%$search%'";

$result = $conn->query($query);

// Delete appointment_details
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id']; // Get the ID to delete
    $delete_query = "DELETE FROM appointment_details WHERE pay_id = '$delete_id'";

    if ($conn->query($delete_query) === TRUE) {
        echo "<script>alert('Appointment deleted successfully');</script>";
    } else {
        echo "<script>alert('Error deleting Appointment: " . $conn->error . "');</script>";
    }

    // Redirect to avoid resubmission of the form
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beauty Salon</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .options {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }
        .option {
            width: 200px;
            padding: 20px;
            text-align: center;
            background-color: #007BFF;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s;
        }
        .option:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse; /* Collapses borders between table cells */
            margin: 20px 0; /* Adds spacing above and below the table */
            font-family: Arial, sans-serif; /* Sets font family */
        }

        th {
            background-color: #007BFF;
            color: white;
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        caption {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .search-form {
    display: flex;
    justify-content: center; /* Centers the form horizontally */
    align-items: center; /* Ensures proper vertical alignment */
    gap: 10px; /* Adds spacing between the input and button */
    margin-bottom: 20px; /* Space below the form */
}

.search-input {
    padding: 10px; /* Adjusts padding for a better look */
    font-size: 16px; /* Increases font size for readability */
    border: 1px solid #ccc; /* Light gray border */
    border-radius: 4px; /* Rounded corners */
    width: 250px; /* Input width */
    transition: border-color 0.3s, box-shadow 0.3s; /* Smooth transition on focus */
}

.search-input:focus {
    border-color: #007BFF; /* Blue border on focus */
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5); /* Glowing effect */
    outline: none; /* Removes default focus outline */
}

.search-btn {
    padding: 10px 15px; /* Increases padding for the button */
    background-color: #007BFF; /* Primary blue color */
    color: white; /* White text color */
    border: none; /* Removes default border */
    border-radius: 4px; /* Rounded corners */
    font-size: 16px; /* Matches font size with input */
    cursor: pointer; /* Adds pointer cursor */
    transition: background-color 0.3s; /* Smooth hover effect */
}

.search-btn:hover {
    background-color: #0056b3; /* Darker blue on hover */
}

        .delete-btn {
            background-color: #f44336; /* Red */
            color: white;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 12px;
        }

        .delete-btn:hover {
            background-color: #e53935;
        }

        .logout {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 10px 15px;
            background-color: #f44336; /* Red color */
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            transition: background-color 0.3s;
        }
        .logout:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <h1>Welcome to Our Beauty Salon</h1>

    <!-- Search Form -->
    <form method="POST" action="" class="search-form">
    <input type="text" name="search" placeholder="Search Appointment..." value="<?php echo $search; ?>" class="search-input">
    <button type="submit" class="search-btn">Search</button>
</form>
        <!-- Logout Button -->
    <a href="logout.php" class="logout">Logout</a>


    <div class="container">
        <h2>Appointment List</h2>
        <table border="1" align="center">
            <tr>
                <th class="option">Pay ID</th>
                <th class="option">Appointment ID</th>
                <th class="option">Service Type ID</th>
                <th class="option">Pay Date</th>
                <th class="option">Pay Method</th>
                <th class="option">Total Bill</th>
                <th class="option">Status</th>
                <th class="option">Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['pay_id']; ?></td>
                    <td><?php echo $row['app_id']; ?></td>
                    <td><?php echo $row['stype_id']; ?></td>
                    <td><?php echo $row['pay_date']; ?></td>
                    <td><?php echo $row['pay_method']; ?></td>
                    <td><?php echo $row['total_bill']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td><a href="?delete_id=<?php echo $row['pay_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this Appointment?')">Delete</a></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <?php
    // Close connection
    $conn->close();
    ?>
</body>
</html>
